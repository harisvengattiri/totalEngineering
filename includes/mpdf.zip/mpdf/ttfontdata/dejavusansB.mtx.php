<?php
$name='DejaVuSans-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 262148,
  'FontBBox' => '[-1069 -415 1975 1174]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 600,
);
$up=-63;
$ut=44;
$ttffile='/home/cybozin/public_html/oasis/includes/mpdf/ttfonts/DejaVuSans-Bold.ttf';
$TTCfontID='0';
$originalsize=584396;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansB';
$panose=' 0 0 2 b 8 3 3 6 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>