<?php
$name='DejaVuSans-Oblique';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 68,
  'FontBBox' => '[-1016 -350 1659 1068]',
  'ItalicAngle' => -11,
  'StemV' => 87,
  'MissingWidth' => 600,
);
$up=-63;
$ut=44;
$ttffile='/home/cybozco/public_html/oasis/includes/mpdf/ttfonts/DejaVuSans-Oblique.ttf';
$TTCfontID='0';
$originalsize=524396;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansI';
$panose=' 0 0 2 b 6 3 3 3 4 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>