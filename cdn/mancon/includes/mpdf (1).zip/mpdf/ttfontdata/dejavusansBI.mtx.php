<?php
$name='DejaVuSans-BoldOblique';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 262212,
  'FontBBox' => '[-1067 -385 1999 1121]',
  'ItalicAngle' => -11,
  'StemV' => 165,
  'MissingWidth' => 600,
);
$up=-63;
$ut=44;
$ttffile='/home/cybozin/public_html/oasis/includes/mpdf/ttfonts/DejaVuSans-BoldOblique.ttf';
$TTCfontID='0';
$originalsize=524624;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansBI';
$panose=' 0 0 2 b 8 3 3 3 4 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>